# SA-Practical

Sample API written in Python using Flask that returns elements like skills, certificatons, achivements from  a static resume

- GitHub - https://github.com/niharkarra/SA-Practical.git
- S3 Bucket - s3://swa-practical/
- Beanstalk Environment - SA-Practical-dev
- CloudFormation Stack - arn:aws:cloudformation:us-east-1:217542142459:stack/awseb-e-3fcdqdtmw4-stack/bafb6d90-0290-11ee-bfc7-0e9281aee647

- Load Balancer - arn:aws:elasticloadbalancing:us-east-1:217542142459:loadbalancer/app/awseb-AWSEB-1QW0JORJ7XF2W/f12c1c2f930c5b3b

- Security Group - sg-04e665a764e2246b1

- Beanstalk URL - http://sa-practical-dev.us-east-1.elasticbeanstalk.com/
- Public URL - https://karnihar.awsps.myinstance.com/

--


