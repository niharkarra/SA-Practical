# SA-Practical

Sample API written in Python using Flask that returns elements like skills, certificatons, achivements from  a static resume
